<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureMask - Ofuscación de Datos PAN</title>
    <link rel="stylesheet" href="Custom.css">
</head>
<body>
    <div class="bg-grid"></div>

    <div class="container">
        <header class="screen-header">
            <a href="home" class="btn-back">
                <span class="back-icon">←</span> Volver al Inicio
            </a>
            <div class="logo-area">
                <span class="logo-icon">🔒</span>
                <div>
                    <div class="logo-text">SecureMask</div>
                    <div class="logo-subtitle">Utilidad de Ofuscación de Datos</div>
                </div>
            </div>
        </header>

        <div class="secure-mask-layout">
            <!-- Left panel: Form -->
            <div class="sm-card">
                <h2 class="sm-title">Ofuscación de Datos PAN</h2>
                <p class="sm-desc">Ingresa un número de tarjeta de 16 dígitos para enmascararlo mediante el backend de Java.</p>
                
                <form id="mask-form" action="ejercicio1" method="POST">
                    <div class="form-group">
                        <label class="form-label" for="pan-input">PAN_NUMBER</label>
                        <div class="input-container">
                            <input type="text" id="pan-input" name="pan" class="input-field" 
                                   placeholder="6516 3516 5136 1365" required maxlength="19" 
                                   value="${param.pan}">
                            <span class="input-badge" id="char-count">0/16</span>
                        </div>
                    </div>

                    <button type="submit" class="btn-cyan" id="btn-submit-card">
                        <span>🔒</span> Procesar y Enmascarar →
                    </button>
                </form>

                <div class="security-note">
                    <span class="security-note-icon">🛡️</span>
                    <p class="security-note-text">
                        <strong>Nota de Seguridad:</strong> Todo el procesamiento ocurre mediante rutinas del backend Java. Ningún dato PAN en bruto es almacenado o registrado permanentemente.
                    </p>
                </div>
            </div>

            <!-- Right panel: Results -->
            <div class="results-panel">
                <div class="result-card">
                    <div class="result-header">
                        <span class="form-label">SALIDA_ENMASCARADA</span>
                        <span class="status-badge" id="mask-status" style="${resultado != null ? 'background: rgba(0, 240, 255, 0.1); border-color: var(--cyan-primary); color: var(--cyan-primary);' : ''}">
                            ${resultado != null ? 'Enmascarado' : 'Inactivo'}
                        </span>
                    </div>
                    <div class="masked-value" id="masked-output">
                        ${resultado != null ? resultado.maskedPart : '•••• •••• •••• '}<span class="highlight">${resultado != null ? resultado.visiblePart : '----'}</span>
                    </div>
                </div>

                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-title">Total de Dígitos</div>
                        <div class="metric-value" id="metric-digits">${resultado != null ? resultado.totalDigits : 0} <span>dígitos</span></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Suma Total</div>
                        <div class="metric-value" id="metric-sum">${resultado != null ? resultado.totalSum : 0} <span>Σ</span></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Suma Dígitos Pares</div>
                        <div class="metric-value" id="metric-even">${resultado != null ? resultado.evenSum : 0} <span>Σ pares</span></div>
                    </div>
                    <div class="metric-card">
                        <div class="metric-title">Suma Dígitos Impares</div>
                        <div class="metric-value" id="metric-odd">${resultado != null ? resultado.oddSum : 0} <span>Σ impares</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer-info">
        <div>SecureMask & Dice Chronicles © 2026 - dilber RH</div>
        <div class="footer-badges">
            <div class="footer-badge">
                <span class="badge-dot cyan"></span> Lógica Backend: Java
            </div>
            <div class="footer-badge">
                <span class="badge-dot gold"></span> Arquitectura: MVC
            </div>
        </div>
    </footer>

    <script>
        // Formato interactivo en el cliente para mejorar el diseño y UX
        const panInput = document.getElementById('pan-input');
        const charCount = document.getElementById('char-count');

        function updateCharBadge(value) {
            charCount.textContent = `${value.length}/16`;
            if (value.length === 16) {
                charCount.style.borderColor = 'var(--cyan-primary)';
                charCount.style.color = 'var(--cyan-primary)';
            } else {
                charCount.style.borderColor = 'rgba(255, 255, 255, 0.08)';
                charCount.style.color = 'var(--text-muted)';
            }
        }

        if (panInput) {
            panInput.addEventListener('input', (e) => {
                let value = e.target.value.replace(/\D/g, '');
                if (value.length > 16) {
                    value = value.substring(0, 16);
                }
                const parts = [];
                for (let i = 0; i < value.length; i += 4) {
                    parts.push(value.substring(i, i + 4));
                }
                e.target.value = parts.join(' ');
                updateCharBadge(value);
            });

            // Inicializar el contador al cargar la página
            const initialValue = panInput.value.replace(/\s/g, '');
            updateCharBadge(initialValue);
        }
    </script>
</body>
</html>
