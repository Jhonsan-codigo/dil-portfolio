package com.mycompany.se9.controller;

import com.mycompany.se9.model.DiceRoller;
import com.mycompany.se9.model.DiceResult;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "Ejercicio2Controller", urlPatterns = {"/ejercicio2"})
public class Ejercicio2Controller extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/Ejercicio2.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String facesStr = request.getParameter("faces");
        int faces = 20; // Default
        
        try {
            if (facesStr != null && !facesStr.trim().isEmpty()) {
                faces = Integer.parseInt(facesStr.trim());
            }
        } catch (NumberFormatException e) {
            faces = 20;
        }
        
        // Invoke Model logic
        DiceResult result = DiceRoller.roll(faces);
        
        // Set Model result to View
        request.setAttribute("resultado", result);
        
        request.getRequestDispatcher("/WEB-INF/views/Ejercicio2.jsp").forward(request, response);
    }
}
