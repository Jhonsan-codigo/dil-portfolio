package com.mycompany.se9.model;

import java.util.concurrent.ThreadLocalRandom;

public class DiceRoller {

    public static DiceResult roll(int faces) {
        if (faces < 2) {
            faces = 2; // Safeguard
        }
        
        int randomValue = ThreadLocalRandom.current().nextInt(1, faces + 1);
        return new DiceResult(faces, randomValue);
    }
}
