<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dilber RH - Portafolio de Proyectos MVC</title>
    <link rel="stylesheet" href="Custom.css">
</head>
<body>
    <div class="bg-grid"></div>

    <div class="container">
        <main id="dashboard-screen" class="screen active">
            <header class="dashboard-header">
                <h1 class="dashboard-title">dilber RH</h1>
                <p class="dashboard-subtitle">Portafolio de Proyectos Java Backend & MVC</p>
            </header>

            <section class="project-grid">
                <!-- Card 1: SecureMask -->
                <a href="ejercicio1" class="project-card card-cyan">
                    <div class="card-num">PROYECTO 01</div>
                    <h2 class="card-title">SecureMask</h2>
                    <p class="card-desc">Ofuscación de Datos PAN. Procesa y enmascara Números de Cuenta Primarios (tarjetas de crédito) mediante rutinas algorítmicas en el backend de Java.</p>
                </a>

                <!-- Card 2: Dice Chronicles -->
                <a href="ejercicio2" class="project-card card-gold">
                    <div class="card-num">PROYECTO 02</div>
                    <h2 class="card-title">Dice Chronicles</h2>
                    <p class="card-desc">Simulador de lanzamiento de dados del destino. Configura el número de caras y lanza un dado para generar un número aleatorio desde el backend de Java.</p>
                </a>
            </section>
        </main>
    </div>

    <footer class="footer-info">
        <div>SecureMask & Dice Chronicles © 2026 - dilber RH</div>
        <div class="footer-badges">
            <div class="footer-badge">
                <span class="badge-dot cyan"></span> Lógica Backend: Java
            </div>
            <div class="footer-badge">
                <span class="badge-dot gold"></span> Arquitectura: MVC
            </div>
        </div>
    </footer>
</body>
</html>
