package com.mycompany.se9.controller;

import com.mycompany.se9.model.CardMasker;
import com.mycompany.se9.model.CardResult;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "Ejercicio1Controller", urlPatterns = {"/ejercicio1"})
public class Ejercicio1Controller extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/Ejercicio1.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pan = request.getParameter("pan");
        
        if (pan != null && !pan.trim().isEmpty()) {
            // Remove spaces if any
            String cleanPan = pan.replaceAll("\\s+", "");
            
            // Invoke Model logic
            CardResult result = CardMasker.process(cleanPan);
            
            // Set Model result to View
            request.setAttribute("resultado", result);
        }
        
        request.getRequestDispatcher("/WEB-INF/views/Ejercicio1.jsp").forward(request, response);
    }
}
