<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dice Chronicles - Lanzamiento de Dados</title>
    <link rel="stylesheet" href="Custom.css">
</head>
<body>
    <div class="bg-grid"></div>

    <div class="container">
        <header class="screen-header">
            <a href="home" class="btn-back">
                <span class="back-icon">←</span> Volver al Inicio
            </a>
            <div class="logo-area">
                <span class="logo-icon">🎲</span>
                <div>
                    <div class="logo-text">Dice Chronicles</div>
                    <div class="logo-subtitle">Proyecto 02</div>
                </div>
            </div>
        </header>

        <div class="dice-container">
            <div class="dice-card">
                <h2 class="dice-title">DICE CHRONICLES</h2>
                <p class="dice-subtitle">Fate is cast in the roll of ancient bones</p>

                <form id="dice-form" action="ejercicio2" method="POST">
                    <div class="form-group">
                        <label class="form-label" for="faces-input">NÚMERO DE CARAS</label>
                        <input type="number" id="faces-input" name="faces" class="input-field" 
                               style="border-color: var(--gold-border);" 
                               value="${param.faces != null ? param.faces : '20'}" min="2" max="1000" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">PREDISEÑADOS (PRESETS)</label>
                        <div class="preset-grid">
                            <button type="button" class="btn-preset ${param.faces == '4' ? 'active' : ''}" onclick="setPreset(4)">d4</button>
                            <button type="button" class="btn-preset ${param.faces == '6' ? 'active' : ''}" onclick="setPreset(6)">d6</button>
                            <button type="button" class="btn-preset ${param.faces == '8' ? 'active' : ''}" onclick="setPreset(8)">d8</button>
                            <button type="button" class="btn-preset ${param.faces == '10' ? 'active' : ''}" onclick="setPreset(10)">d10</button>
                            <button type="button" class="btn-preset ${param.faces == '12' ? 'active' : ''}" onclick="setPreset(12)">d12</button>
                            <button type="button" class="btn-preset ${param.faces == null || param.faces == '20' ? 'active' : ''}" onclick="setPreset(20)">d20</button>
                            <button type="button" class="btn-preset ${param.faces == '100' ? 'active' : ''}" onclick="setPreset(100)">d100</button>
                        </div>
                    </div>

                    <button type="submit" class="btn-gold" id="btn-roll-dice">
                        ROLL DICE
                    </button>
                </form>
            </div>

            <div class="dice-result-card" id="dice-container-data" data-result="${resultado != null ? resultado.result : ''}" data-faces="${resultado != null ? resultado.faces : ''}">
                <h3 class="dice-result-label" id="result-label">
                    ${resultado != null ? 'ORACLE\'S RESULT — D'.concat(resultado.faces) : 'ORACLE\'S RESULT — D20'}
                </h3>
                
                <div class="dice-view">
                    <div class="dice-shape" id="dice-graphic"></div>
                    <div class="dice-value" id="dice-result">-</div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer-info">
        <div>SecureMask & Dice Chronicles © 2026 - dilber RH</div>
        <div class="footer-badges">
            <div class="footer-badge">
                <span class="badge-dot cyan"></span> Lógica Backend: Java
            </div>
            <div class="footer-badge">
                <span class="badge-dot gold"></span> Arquitectura: MVC
            </div>
        </div>
    </footer>

    <script>
        function setPreset(faces) {
            const facesInput = document.getElementById('faces-input');
            if (facesInput) {
                facesInput.value = faces;
            }
            
            const presets = document.querySelectorAll('.btn-preset');
            presets.forEach(btn => {
                btn.classList.remove('active');
                if (btn.textContent === `d${faces}`) {
                    btn.classList.add('active');
                }
            });
            
            document.getElementById('result-label').textContent = `ORACLE'S RESULT — D${faces}`;
            document.getElementById('dice-result').textContent = '-';
        }

        // Lógica de animación para simular el tiro de dado cuando carga el resultado
        window.addEventListener('DOMContentLoaded', () => {
            const dataContainer = document.getElementById('dice-container-data');
            const resultVal = dataContainer.getAttribute('data-result');
            const facesVal = dataContainer.getAttribute('data-faces');
            
            if (resultVal) {
                const graphic = document.getElementById('dice-graphic');
                const resultText = document.getElementById('dice-result');
                const rollBtn = document.getElementById('btn-roll-dice');
                
                // Activar animación
                graphic.classList.add('rolling');
                resultText.textContent = '?';
                rollBtn.disabled = true;
                rollBtn.textContent = 'CASTING...';
                
                // Mostrar el resultado definitivo después de 600ms de animación
                setTimeout(() => {
                    graphic.classList.remove('rolling');
                    resultText.textContent = resultVal;
                    rollBtn.disabled = false;
                    rollBtn.textContent = 'ROLL DICE';
                }, 600);
            }
        });
    </script>
</body>
</html>
