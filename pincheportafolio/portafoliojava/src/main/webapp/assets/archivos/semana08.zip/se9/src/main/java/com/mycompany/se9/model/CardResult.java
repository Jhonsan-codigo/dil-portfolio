package com.mycompany.se9.model;

import java.io.Serializable;

public class CardResult implements Serializable {
    private static final long serialVersionUID = 1L;

    private String maskedPan;
    private int totalDigits;
    private int totalSum;
    private int evenSum;
    private int oddSum;

    public CardResult() {
    }

    public CardResult(String maskedPan, int totalDigits, int totalSum, int evenSum, int oddSum) {
        this.maskedPan = maskedPan;
        this.totalDigits = totalDigits;
        this.totalSum = totalSum;
        this.evenSum = evenSum;
        this.oddSum = oddSum;
    }

    public String getMaskedPan() {
        return maskedPan;
    }

    public String getMaskedPart() {
        if (maskedPan == null || maskedPan.length() < 4) return "";
        return maskedPan.substring(0, maskedPan.length() - 4);
    }

    public String getVisiblePart() {
        if (maskedPan == null || maskedPan.length() < 4) return "";
        return maskedPan.substring(maskedPan.length() - 4);
    }

    public void setMaskedPan(String maskedPan) {
        this.maskedPan = maskedPan;
    }

    public int getTotalDigits() {
        return totalDigits;
    }

    public void setTotalDigits(int totalDigits) {
        this.totalDigits = totalDigits;
    }

    public int getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(int totalSum) {
        this.totalSum = totalSum;
    }

    public int getEvenSum() {
        return evenSum;
    }

    public void setEvenSum(int evenSum) {
        this.evenSum = evenSum;
    }

    public int getOddSum() {
        return oddSum;
    }

    public void setOddSum(int oddSum) {
        this.oddSum = oddSum;
    }
}
