package com.mycompany.se9.model;

public class CardMasker {

    public static CardResult process(String rawPan) {
        if (rawPan == null) {
            return new CardResult("•••• •••• •••• ••••", 0, 0, 0, 0);
        }

        // Remove any whitespace or formatting
        String cleanPan = rawPan.replaceAll("\\s+", "");
        int length = cleanPan.length();

        int totalSum = 0;
        int evenSum = 0;
        int oddSum = 0;

        for (int i = 0; i < length; i++) {
            char c = cleanPan.charAt(i);
            if (Character.isDigit(c)) {
                int digit = Character.getNumericValue(c);
                totalSum += digit;
                if (digit % 2 == 0) {
                    evenSum += digit;
                } else {
                    oddSum += digit;
                }
            }
        }

        // Build the masked string with spaces every 4 characters
        StringBuilder maskedBuilder = new StringBuilder();
        for (int i = 0; i < length; i++) {
            if (i > 0 && i % 4 == 0) {
                maskedBuilder.append(" ");
            }
            
            // Keep the last 4 characters visible, mask the rest
            if (i < length - 4) {
                maskedBuilder.append("•");
            } else {
                maskedBuilder.append(cleanPan.charAt(i));
            }
        }

        String maskedPan = maskedBuilder.toString();
        return new CardResult(maskedPan, length, totalSum, evenSum, oddSum);
    }
}
