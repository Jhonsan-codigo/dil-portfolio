package com.mycompany.se9.model;

import java.io.Serializable;

public class DiceResult implements Serializable {
    private static final long serialVersionUID = 1L;

    private int faces;
    private int result;

    public DiceResult() {
    }

    public DiceResult(int faces, int result) {
        this.faces = faces;
        this.result = result;
    }

    public int getFaces() {
        return faces;
    }

    public void setFaces(int faces) {
        this.faces = faces;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }
}
