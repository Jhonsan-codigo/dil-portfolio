package com.mycompany.s9dilber.model;

import java.io.Serializable;

public class CompraModel implements Serializable {
    private static final long serialVersionUID = 1L;

    // Entradas
    private double precioDocena;
    private int cantidadDocenas;

    // Salidas
    private double importeCompra;
    private double descuentoPercent;
    private double importeDescuento;
    private double importePagar;
    private int lapicerosRegalo;

    public CompraModel() {
    }

    public CompraModel(double precioDocena, int cantidadDocenas) {
        this.precioDocena = precioDocena;
        this.cantidadDocenas = cantidadDocenas;
        calculate();
    }

    private void calculate() {
        this.importeCompra = this.precioDocena * this.cantidadDocenas;

        if (this.cantidadDocenas >= 10) {
            this.descuentoPercent = 20.0;
        } else {
            this.descuentoPercent = 10.0;
        }

        this.importeDescuento = this.importeCompra * (this.descuentoPercent / 100.0);
        this.importePagar = this.importeCompra - this.importeDescuento;

        if (this.importePagar >= 200.0) {
            this.lapicerosRegalo = this.cantidadDocenas * 2;
        } else {
            this.lapicerosRegalo = 0;
        }
    }

    // Getters y Setters
    public double getPrecioDocena() {
        return precioDocena;
    }

    public void setPrecioDocena(double precioDocena) {
        this.precioDocena = precioDocena;
    }

    public int getCantidadDocenas() {
        return cantidadDocenas;
    }

    public void setCantidadDocenas(int cantidadDocenas) {
        this.cantidadDocenas = cantidadDocenas;
    }

    public double getImporteCompra() {
        return importeCompra;
    }

    public double getDescuentoPercent() {
        return descuentoPercent;
    }

    public double getImporteDescuento() {
        return importeDescuento;
    }

    public double getImportePagar() {
        return importePagar;
    }

    public int getLapicerosRegalo() {
        return lapicerosRegalo;
    }

    // Métodos de formato para JSP
    public String getFormattedPrecioDocena() {
        return String.format("%.2f", precioDocena);
    }

    public String getFormattedImporteCompra() {
        return String.format("%.2f", getImporteCompra());
    }

    public String getFormattedDescuentoPercent() {
        return String.format("%.0f", getDescuentoPercent());
    }

    public String getFormattedImporteDescuento() {
        return String.format("%.2f", getImporteDescuento());
    }

    public String getFormattedImportePagar() {
        return String.format("%.2f", getImportePagar());
    }
}
