package com.mycompany.s9dilber.model;

import java.io.Serializable;

public class SueldoModel implements Serializable {
    private static final long serialVersionUID = 1L;

    // Entradas
    private String nombreEmpleado;
    private String categoria;
    private double horasTrabajadas;
    private int numeroHijos;

    // Salidas
    private double tarifaHoraria;
    private double sueldoBasico;
    private double bonificacionHijos;
    private double sueldoBruto;
    private double descuentoAfpPercent;
    private double descuentoAfp;
    private double sueldoNeto;

    public SueldoModel() {
    }

    public SueldoModel(String nombreEmpleado, String categoria, double horasTrabajadas, int numeroHijos) {
        this.nombreEmpleado = nombreEmpleado;
        this.categoria = categoria;
        this.horasTrabajadas = horasTrabajadas;
        this.numeroHijos = numeroHijos;
        calculate();
    }

    private void calculate() {
        if ("A".equalsIgnoreCase(this.categoria)) {
            this.tarifaHoraria = 45.0;
        } else {
            this.tarifaHoraria = 37.5;
            this.categoria = "B"; // Normalizar
        }

        this.sueldoBasico = this.horasTrabajadas * this.tarifaHoraria;

        if (this.numeroHijos <= 3) {
            this.bonificacionHijos = this.numeroHijos * 40.5;
        } else {
            this.bonificacionHijos = this.numeroHijos * 35.0;
        }

        this.sueldoBruto = this.sueldoBasico + this.bonificacionHijos;

        if (this.sueldoBruto >= 3500.0) {
            this.descuentoAfpPercent = 13.5;
        } else {
            this.descuentoAfpPercent = 10.0;
        }

        this.descuentoAfp = this.sueldoBruto * (this.descuentoAfpPercent / 100.0);
        this.sueldoNeto = this.sueldoBruto - this.descuentoAfp;
    }

    // Getters y Setters
    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public void setHorasTrabajadas(double horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }

    public int getNumeroHijos() {
        return numeroHijos;
    }

    public void setNumeroHijos(int numeroHijos) {
        this.numeroHijos = numeroHijos;
    }

    public double getTarifaHoraria() {
        return tarifaHoraria;
    }

    public double getSueldoBasico() {
        return sueldoBasico;
    }

    public double getBonificacionHijos() {
        return bonificacionHijos;
    }

    public double getSueldoBruto() {
        return sueldoBruto;
    }

    public double getDescuentoAfpPercent() {
        return descuentoAfpPercent;
    }

    public double getDescuentoAfp() {
        return descuentoAfp;
    }

    public double getSueldoNeto() {
        return sueldoNeto;
    }

    // Métodos de formato para JSP
    public String getFormattedTarifaHoraria() {
        return String.format("%.2f", tarifaHoraria);
    }

    public String getFormattedHorasTrabajadas() {
        return String.format("%.1f", horasTrabajadas);
    }

    public String getFormattedSueldoBasico() {
        return String.format("%.2f", getSueldoBasico());
    }

    public String getFormattedBonificacionHijos() {
        return String.format("%.2f", getBonificacionHijos());
    }

    public String getFormattedSueldoBruto() {
        return String.format("%.2f", getSueldoBruto());
    }

    public String getFormattedDescuentoAfpPercent() {
        return String.format("%.1f", getDescuentoAfpPercent());
    }

    public String getFormattedDescuentoAfp() {
        return String.format("%.2f", getDescuentoAfp());
    }

    public String getFormattedSueldoNeto() {
        return String.format("%.2f", getSueldoNeto());
    }
}
