package com.mycompany.s9dilber.controller;

import com.mycompany.s9dilber.model.CompraModel;
import com.mycompany.s9dilber.model.SueldoModel;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "DashboardServlet", urlPatterns = {"/dashboard", "/home"})
public class DashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("activeTab", "compra");
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String calculatorType = request.getParameter("calculatorType");
        
        if ("compra".equals(calculatorType)) {
            request.setAttribute("activeTab", "compra");
            try {
                double precioDocena = Double.parseDouble(request.getParameter("precioDocena"));
                int cantidadDocenas = Integer.parseInt(request.getParameter("cantidadDocenas"));
                
                CompraModel compra = new CompraModel(precioDocena, cantidadDocenas);
                request.setAttribute("compraResult", compra);
            } catch (NumberFormatException e) {
                request.setAttribute("compraError", "Por favor ingresa valores numéricos válidos.");
            }
        } else if ("sueldo".equals(calculatorType)) {
            request.setAttribute("activeTab", "sueldo");
            try {
                String nombreEmpleado = request.getParameter("nombreEmpleado");
                String categoria = request.getParameter("categoria");
                double horasTrabajadas = Double.parseDouble(request.getParameter("horasTrabajadas"));
                int numeroHijos = Integer.parseInt(request.getParameter("numeroHijos"));
                
                if (nombreEmpleado == null || nombreEmpleado.trim().isEmpty()) {
                    nombreEmpleado = "Empleado";
                }
                
                SueldoModel sueldo = new SueldoModel(nombreEmpleado, categoria, horasTrabajadas, numeroHijos);
                request.setAttribute("sueldoResult", sueldo);
            } catch (NumberFormatException e) {
                request.setAttribute("sueldoError", "Por favor ingresa valores numéricos válidos.");
            }
        }
        
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}
