<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dilber RH - Dashboard de Lógica de Negocio</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="bg-grid"></div>

    <div class="container">
        <!-- Header -->
        <header class="dashboard-header">
            <h1 class="dashboard-title">DASHBOARD<span>.BUSINESS</span></h1>
            <p class="dashboard-subtitle">Lógica de Negocio en Arquitectura Java EE & MVC</p>
        </header>

        <!-- Tabs Navigation -->
        <nav class="tabs-nav">
            <button class="tab-btn ${activeTab == 'sueldo' ? '' : 'active'}" data-tab="tab-compra">
                <span>🛒</span> Compra de Docenas
            </button>
            <button class="tab-btn ${activeTab == 'sueldo' ? 'active' : ''}" data-tab="tab-sueldo">
                <span>💼</span> Planilla de Empleados
            </button>
        </nav>

        <!-- TAB 1: Calculadora de Compra de Docenas -->
        <div id="tab-compra" class="tab-content ${activeTab == 'sueldo' ? '' : 'active'}">
            <!-- Form Card -->
            <div class="panel-card">
                <h2 class="panel-title"><span>🛒</span> Compra de Docenas</h2>
                <p class="panel-desc">Calcula el importe de compra, descuentos (10% o 20%) y obsequio de lapiceros si el importe final supera los S/. 200.</p>
                
                <% if (request.getAttribute("compraError") != null) { %>
                    <div class="error-banner">
                        <span>⚠️</span> <%= request.getAttribute("compraError") %>
                    </div>
                <% } %>

                <form action="dashboard" method="POST">
                    <input type="hidden" name="calculatorType" value="compra">
                    
                    <div class="form-group">
                        <label class="form-label" for="precioDocena">Precio de la Docena (S/.)</label>
                        <div class="input-container">
                            <input type="number" step="0.01" min="0.01" id="precioDocena" name="precioDocena" class="input-field" 
                                   placeholder="0.00" required
                                   value="${compraResult != null ? compraResult.precioDocena : ''}">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="cantidadDocenas">Cantidad de Docenas</label>
                        <div class="input-container">
                            <input type="number" min="1" id="cantidadDocenas" name="cantidadDocenas" class="input-field" 
                                   placeholder="0" required
                                   value="${compraResult != null ? compraResult.cantidadDocenas : ''}">
                        </div>
                    </div>

                    <button type="submit" class="btn-gold">
                        <span>$</span> Calcular Importe
                    </button>
                </form>
            </div>

            <!-- Results Panel -->
            <div class="results-panel">
                <div class="result-card-main">
                    <div class="result-header">
                        <span class="form-label">Importe a Pagar</span>
                        <span class="status-badge ${compraResult != null ? 'active' : ''}">
                            ${compraResult != null ? 'Calculado' : 'Esperando datos'}
                        </span>
                    </div>
                    <div class="result-value-large">
                        <span>S/.</span>${compraResult != null ? compraResult.formattedImportePagar : '0.00'}
                    </div>
                </div>

                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-title">Importe de Compra</div>
                        <div class="metric-value">
                            <span>S/.</span>${compraResult != null ? compraResult.formattedImporteCompra : '0.00'}
                        </div>
                    </div>
                    
                    <div class="metric-card">
                        <div class="metric-title">Descuento Aplicado</div>
                        <div class="metric-value highlight-gold">
                            <span>S/.</span>${compraResult != null ? compraResult.formattedImporteDescuento : '0.00'}
                            <span style="font-size: 0.9rem; color: var(--text-muted); font-weight: 400;">
                                ${compraResult != null ? '(' += compraResult.formattedDescuentoPercent += '%)' : ''}
                            </span>
                        </div>
                    </div>

                    <div class="metric-card" style="grid-column: span 2;">
                        <div class="metric-title">Obsequio (Lapiceros)</div>
                        <div class="metric-value" style="color: var(--text-primary);">
                            ${compraResult != null ? compraResult.lapicerosRegalo : '0'} <span>lapiceros</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- TAB 2: Calculadora de Planilla de Empleados -->
        <div id="tab-sueldo" class="tab-content ${activeTab == 'sueldo' ? 'active' : ''}">
            <!-- Form Card -->
            <div class="panel-card">
                <h2 class="panel-title"><span>💼</span> Planilla de Empleados</h2>
                <p class="panel-desc">Calcula el sueldo básico, la bonificación familiar por hijos, retenciones y el neto a pagar.</p>

                <% if (request.getAttribute("sueldoError") != null) { %>
                    <div class="error-banner">
                        <span>⚠️</span> <%= request.getAttribute("sueldoError") %>
                    </div>
                <% } %>

                <form action="dashboard" method="POST">
                    <input type="hidden" name="calculatorType" value="sueldo">

                    <div class="form-group">
                        <label class="form-label" for="nombreEmpleado">Nombre del Empleado</label>
                        <div class="input-container">
                            <input type="text" id="nombreEmpleado" name="nombreEmpleado" class="input-field" 
                                   placeholder="Ej. Juan Pérez" required
                                   value="${sueldoResult != null ? sueldoResult.nombreEmpleado : ''}">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="categoria">Categoría del Empleado</label>
                        <div class="input-container">
                            <select id="categoria" name="categoria" class="input-field" style="appearance: none; -webkit-appearance: none;">
                                <option value="A" ${sueldoResult != null && sueldoResult.categoria == 'A' ? 'selected' : ''}>Categoría A (Tarifa: S/. 45.00/h)</option>
                                <option value="B" ${sueldoResult != null && sueldoResult.categoria == 'B' ? 'selected' : ''}>Categoría B (Tarifa: S/. 37.50/h)</option>
                            </select>
                            <span style="position: absolute; right: 1.5rem; pointer-events: none; color: var(--gold);">▼</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="horasTrabajadas">Horas Trabajadas</label>
                        <div class="input-container">
                            <input type="number" step="0.5" min="1" id="horasTrabajadas" name="horasTrabajadas" class="input-field" 
                                   placeholder="40" required
                                   value="${sueldoResult != null ? sueldoResult.horasTrabajadas : ''}">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="numeroHijos">Número de Hijos</label>
                        <div class="input-container">
                            <input type="number" min="0" id="numeroHijos" name="numeroHijos" class="input-field" 
                                   placeholder="0" required
                                   value="${sueldoResult != null ? sueldoResult.numeroHijos : '0'}">
                        </div>
                    </div>

                    <button type="submit" class="btn-gold">
                        <span>$</span> Calcular Planilla
                    </button>
                </form>
            </div>

            <!-- Results Panel -->
            <div class="results-panel">
                <div class="result-card-main">
                    <div class="result-header">
                        <span class="form-label">Sueldo Neto a Recibir (${sueldoResult != null ? sueldoResult.nombreEmpleado : 'Empleado'})</span>
                        <span class="status-badge ${sueldoResult != null ? 'active' : ''}">
                            ${sueldoResult != null ? 'Calculado' : 'Esperando datos'}
                        </span>
                    </div>
                    <div class="result-value-large">
                        <span>S/.</span>${sueldoResult != null ? sueldoResult.formattedSueldoNeto : '0.00'}
                    </div>
                </div>

                <div class="metrics-grid">
                    <div class="metric-card">
                        <div class="metric-title">Sueldo Básico</div>
                        <div class="metric-value">
                            <span>S/.</span>${sueldoResult != null ? sueldoResult.formattedSueldoBasico : '0.00'}
                        </div>
                    </div>

                    <div class="metric-card">
                        <div class="metric-title">Bonificación Hijos</div>
                        <div class="metric-value highlight-gold">
                            <span>S/.</span>${sueldoResult != null ? sueldoResult.formattedBonificacionHijos : '0.00'}
                        </div>
                    </div>

                    <div class="metric-card">
                        <div class="metric-title">Sueldo Bruto</div>
                        <div class="metric-value">
                            <span>S/.</span>${sueldoResult != null ? sueldoResult.formattedSueldoBruto : '0.00'}
                        </div>
                    </div>

                    <div class="metric-card">
                        <div class="metric-title">Retención (AFP)</div>
                        <div class="metric-value" style="color: #eb5757;">
                            <span>S/.</span>${sueldoResult != null ? sueldoResult.formattedDescuentoAfp : '0.00'}
                            <span style="font-size: 0.85rem; color: #eb5757; opacity: 0.8;">
                                ${sueldoResult != null ? '(' += sueldoResult.formattedDescuentoAfpPercent += '%)' : ''}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer-info">
        <div>DASHBOARD.BUSINESS © 2026 - dilber RH</div>
        <div class="footer-badges">
            <div class="footer-badge">
                <span class="badge-dot gold"></span> Lógica: Java EE Servlet
            </div>
            <div class="footer-badge">
                <span class="badge-dot gold"></span> Arquitectura: MVC
            </div>
        </div>
    </footer>

    <!-- Interactive Client-side Tab Switcher -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const tabs = document.querySelectorAll('.tab-btn');
            const contents = document.querySelectorAll('.tab-content');

            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    const target = tab.dataset.tab;

                    // Update buttons
                    tabs.forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');

                    // Update contents
                    contents.forEach(content => {
                        if (content.id === target) {
                            content.classList.add('active');
                        } else {
                            content.classList.remove('active');
                        }
                    });
                });
            });
        });
    </script>
</body>
</html>
